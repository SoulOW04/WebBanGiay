﻿$('body').on('click', '.add-to-cart', function (e) {
    e.preventDefault();
    const id = $(this).data('id');
    alert();
})